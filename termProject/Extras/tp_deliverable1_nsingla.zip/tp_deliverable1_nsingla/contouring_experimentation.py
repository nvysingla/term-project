#This file simply shows my work in learning to contour an image, get its bounding box


import numpy as np
import cv2

kernel = np.ones((3,3), np.uint8)
def erode(image):
    return cv2.erode(image, kernel)

# separate disjoint parts of an image
# connected by only small slivers.
def open1(image):
    return dilate(erode(image))
def resizeImage(path,(pixelRows,pixelCols)=(300,300)):    
    return cv2.resize(path,(pixelRows,pixelCols))
def thresholdImage(image):
    image=cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    (threshVal,threshed)=cv2.threshold(image,150,255,cv2.THRESH_BINARY)
    
    return threshed
def close(image):
    return erode(dilate(image))
def dilate(image):
    return cv2.dilate(image, kernel)

im = (close(dilate(resizeImage(cv2.imread('abcd.jpg')))))

thresh = thresholdImage(im)
cv2.imshow("imagwdefe",thresh)
contours, hierarchy = cv2.findContours(thresh,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)



for cnt in contours:
     if cv2.contourArea(cnt)>50:
         x,y,w,h = cv2.boundingRect(cnt)
         cv2.rectangle(im,(x,y),(x+w,y+h),(0,255,0),2)
##         for cntA in cv2.findContours((thresholdImage(resizeImage(cv2.imread("A.jpg")))),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)[0]:
##             if np.equal(cnt.all,cntA.all):
##                 print("A found")
         #print cnt,len(cnt)
         epsilon = 0.1*cv2.arcLength(cnt,True)
         approx = cv2.approxPolyDP(cnt,epsilon,True)
##     if cv2.contourArea(cnt)<20 or  len(cnt)<=2:
##         newArr=np.delete(contours,cnt)

#print len(contours[0]),len(newArr)
cv2.drawContours(im,contours,-1,(0,0,255),3)

cv2.imshow("image",im)
cv2.imshow("image2",thresh)
cv2.waitKey()
cv2.destroyAllWindows()
