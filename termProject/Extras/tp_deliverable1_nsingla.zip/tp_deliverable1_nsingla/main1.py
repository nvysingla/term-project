import cv2
import numpy as np

from pytesser import*
import Image


def resizeImage(path,(pixelRows,pixelCols)=(300,300)):  #resizes the image  
    return cv2.resize(path,(pixelRows,pixelCols))

def imageEdges(path): #gets all edges in the image
    return cv2.Canny(path,100,200)

def thresholdImage(image): 
    image=cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)#converts to grey scale
    (threshVal,threshed)=cv2.threshold(image,120,255,cv2.THRESH_BINARY)
    #all pixels above 120 are made black else white
    return threshed

def detectHandwrittenText(path):
    image=resizeImage(cv2.imread(path,1))
    threshedImage=thresholdImage(image)
    cv2.imwrite("output.jpg",threshedImage)#creates a fresh image
    image=Image.open("output.jpg")#the fresh image is put into pytesser
    outputText=image_to_string(image)
    print outputText

#test__code
#image=resizeImage(cv2.imread("test7.jpg",1))
#edgesImage=imageEdges(image)
#threshedImage=thresholdImage(image)

#cv2.imshow("Image",threshedImage)
#cv2.imwrite("image2.jpg",threshedImage)


def detectPrintedText(imagePath):
#the imagePath is the image name
#it must be stored in the same folder as the .py file
    image = Image.open(imagePath)
    text= image_to_string(image)
    print text

detectHandwrittenText("C:\\Users\\Naviya\\Desktop\\112 Term Project Stuff\\test3.jpg")

cv2.waitKey()
cv2.destroyAllWindows()
