'''
SOURCES:
1. Taking a Photo: http://stackoverflow.com/questions/19448644/save-image-when-pressing-a-key-python-opencv
2. Using the pytesser and pyttsx modules have been adapted from the official documentaton for these modules
and also the following stackoverflow posts:
http://stackoverflow.com/questions/32499491/python-text-to-speech-using-pyttsx
3. the Animation framework is from the 112 Course Notes
'''

from Tkinter import *
#Image Libraries
import cv
import cv2
import Image
#Numbers
import numpy as np
#Speech to text Library
import pyttsx
#Image to text module
from pytesser import*

def getInputImage(data):
    timeCount=200
    cv.NamedWindow("Input Image", cv.CV_WINDOW_AUTOSIZE)
    camera_index = 0
    capture = cv.CaptureFromCAM(camera_index)   

    def repeat():
     frame = cv.QueryFrame(capture)
     cv.ShowImage("Input Image", frame)
     c = cv.WaitKey(25)
     
     if (c == 32): #32 checks for ascii space
      data.picNum+=1
      cv.SaveImage("input"+str(data.picNum)+".jpg",frame)
      data.mode.takeImage=False
      cv2.destroyAllWindows()
      #else: say message
      
    while data.mode.takeImage==True:
        timeCount+=1
        if timeCount>=200:
            timeCount=0
            sayText("press space to take a picture")
        repeat()
        
def detectPrintedText(imagePath):
#the imagePath is the image name
#it must be stored in the same folder as the .py file  
    image = Image.open(imagePath)
    text= image_to_string(image)
    return text

def sayText(text):
    engine = pyttsx.init()
    engine.say(text)
    engine.runAndWait()

class Mode(object):
    def __init__(self):
        pass
    def drawMode(self,canvas,data):
        pass
    def keyPressed(self,data):
        pass
    def mousePressed(self,x,data):
        pass
    def timerFired(self,data):
        pass
    
class startMode(Mode):
    def __init__(self):
        self.label="start"
        self.takeImage=True
        self.message="Press Space to click a picture"
        self.count=70

    def drawMode(self,canvas,data):
        canvas.create_rectangle(0,0,data.width,data.height,fill="green")
        
    def keyPressed(self,data):
        getInputImage(data)
        self.takeImage=True #needs to be reset because out of loop
        data.mode=gettype
    def timerFired(self,data):
        self.count+=1
        if self.count>=70:
            self.count=0
            sayText("press space to switch on the webcam")
        print self.message #maybe say initial message to start camera and then instructions for using camera

class getInputTypeMode(Mode):
    def __init__(self):
        self.timeCount=0
        self.label="gettype"
    def drawMode(self,canvas,data):
        canvas.create_rectangle(0,0,data.width/2,data.height,fill="green")
        canvas.create_text(data.width//4,data.height//2,text="Printed Text")
        canvas.create_rectangle(data.width//2,0,data.width,data.height,fill="blue")
        canvas.create_text(data.width*3/4,data.height/2,text="Handwritten Text")
        
    def timerFired(self,data):
        self.timeCount+=1
        if self.timeCount>=100:
            self.timeCount=0
            #say message right for printed or left for handwritten
            
    def mousePressed(self,x,data):
        if 0<=x and x<data.width//2:
            data.mode=printed
        else:
            #speak confirmation message
            #start processing
            #change mode
            print "Handwritten"
            data.mode=blank
            
class TranslatePrinted(Mode):
    def __init__(self):
        self.label="printedtranslate"
        self.count=0
    def drawMode(self,canvas,data):
        canvas.create_text(data.width//2,data.height//2,text="Translating")
    def timerFired(self,data):
        self.translate(data)
        self.count+=1
        print "inTranslate"
        #check value
        #speak instructions
    def emptyStringError(self):
        #speak instructions to click another image on keyPressed
        print "inErrorMode"
    def translate(self,data):
        firstPath="C:\\Users\\Naviya\\Desktop\\112 Term Project Stuff\\"
        data.detectedText=detectPrintedText(firstPath+"input"+str(data.picNum)+".jpg")
        if data.detectedText==None or data.detectedText.isspace():
            self.emptyStringError()
            data.mode=start
            data.mode.count=70
        else:
            #change to output mode type
            print data.detectedText
            print "changing mode"
            data.mode=getoutputtype

class chooseOutput(Mode):
    def __init__(self):
        self.count=0
        self.label="getoutputtype"
    def drawMode(self,canvas,data):
        canvas.create_rectangle(0,0,data.width/2,data.height,fill="green")
        canvas.create_text(data.width//4,data.height//2,text="Say it out aloud")
        canvas.create_rectangle(data.width//2,0,data.width,data.height,fill="blue")
        canvas.create_text(data.width*3/4,data.height/2,text="Print as Braille")
    def mousePressed(self,x,data):
        if 0<=x and x<data.width//2:
            print "Speak Screen"
            data.mode=blank
        else:
            #speak confirmation message
            #start processing
            #change mode
            print "Braille"
            data.mode=blank
        
    def timerFired(self,data):
        pass

class Blank(Mode):
    def __init__(self):
        self.label="blank"
        self.count=0
    def drawMode(self,canvas,data):
        canvas.create_text(data.width//2,data.height//2,text="Under construction")
    def timerFired(self,data):
        #do nothing
        print "inBlankTImerFired"
        self.count+=1      
        
            
        
start=startMode()
gettype=getInputTypeMode()
printed=TranslatePrinted()
blank=Blank()
getoutputtype=chooseOutput()


####################################
# Central Control
####################################

def init(data):
    data.mode=start
    data.picNum=0
    data.detectedText=""


def mousePressed(event, data):
    data.mode.mousePressed(event.x,data)
    
def keyPressed(event, data):
    if data.mode.label=="start":
        data.mode.keyPressed(data)

def timerFired(data):
    data.mode.timerFired(data)
        

def redrawAll(canvas, data):
    data.mode.drawMode(canvas,data)
        


####################################
# use the run function as-is
####################################

def run(width=300, height=300):
    def redrawAllWrapper(canvas, data):
        canvas.delete(ALL)
        redrawAll(canvas, data)
        canvas.update()    

    def mousePressedWrapper(event, canvas, data):
        mousePressed(event, data)
        redrawAllWrapper(canvas, data)

    def keyPressedWrapper(event, canvas, data):
        keyPressed(event, data)
        redrawAllWrapper(canvas, data)

    def timerFiredWrapper(canvas, data):
        timerFired(data)
        redrawAllWrapper(canvas, data)
        # pause, then call timerFired again
        canvas.after(data.timerDelay, timerFiredWrapper, canvas, data)
    # Set up data and call init
    class Struct(object): pass
    data = Struct()
    data.width = width
    data.height = height
    data.timerDelay = 100 # milliseconds
    init(data)
    # create the root and the canvas
    root = Tk()
    canvas = Canvas(root, width=data.width, height=data.height)
    canvas.pack()
    # set up events
    root.bind("<Button-1>", lambda event:
                            mousePressedWrapper(event, canvas, data))
    root.bind("<Key>", lambda event:
                            keyPressedWrapper(event, canvas, data))
    timerFiredWrapper(canvas, data)
    # and launch the app
    root.mainloop()  # blocks until window is closed
    print("bye!")

run(400, 400)
